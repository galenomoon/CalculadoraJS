window.calculator = new CalcControler();
